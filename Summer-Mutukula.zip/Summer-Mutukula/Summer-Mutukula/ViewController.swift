    //
    //  ViewController.swift
    //  Summer-Mutukula
    //
    //  Created by Shiva Kumar Mutukula on 30/01/18.
    //  Copyright © 2018 Shiva Kumar Mutukula. All rights reserved.
    //

    import UIKit

    class ViewController: UIViewController {
        @IBOutlet weak var lowTF: UITextField!
        @IBOutlet weak var highTF: UITextField!
        @IBOutlet weak var skipTF: UITextField!
        @IBOutlet weak var resultLBL: UILabel!
        @IBOutlet weak var sumLowToHighLBL: UILabel!
        @IBOutlet weak var sumWithSkipLBL: UILabel!
        @IBOutlet weak var seqLBL: UILabel!
        @IBAction func buttonAction(_ sender: Any) {
    //        var low = lowTF.text

            var lowvalue = Int(lowTF.text!)
            var highvalue = Int(highTF.text!)
            let skipvalue = Int(skipTF.text!)
            if(lowvalue == nil || highvalue == nil || skipvalue == nil){
                resultLBL.isHidden = false
                resultLBL.textColor = UIColor.red
                resultLBL.text = "Enter correct values"
            }else
            {
                if(lowvalue! > highvalue!){
                    let temp = lowvalue!
                    lowvalue = highvalue!
                    highvalue = temp
                }
                var sum = 0
                for val in lowvalue!...highvalue!{
                    sum += val
                }
                    resultLBL.isHidden = false
                resultLBL.text = "sum is all integers from low to high" + String(sum)
                var sumLT = 0
                var adding_value = 1
                var nums = [Int]()
                nums.append(lowvalue!)
                var condition = true
                var i = 0
                while(condition){
                    var anInt = nums[i] + adding_value
                    adding_value += 1
                    i += 1
                    if(anInt <= highvalue!){
                        nums.append(anInt)
                    }
                    else{
                        condition = false
                    }
                }
                for i in nums{
                    sumLT += i
                }
                sumLowToHighLBL.isHidden = false
                sumLowToHighLBL.text = "Sum with increasing distance one each time is " + String(sumLT)
                
                sumWithSkipLBL.isHidden = false
                var sumskip = 0
                var arrOfSkipNums = [Int]()
                for i in stride(from: lowvalue!, through: highvalue!, by: skipvalue!){
                    arrOfSkipNums.append(i)
                    sumskip += i
                }
                sumWithSkipLBL.text = "Sum with Skip values " + String(sumskip)
                seqLBL.isHidden = false
                seqLBL.text = "Sequence of integers " + String(describing: arrOfSkipNums)
                
                
        }
    }
        
        override func viewDidLoad() {
            super.viewDidLoad()
            resultLBL.isHidden = true
            sumLowToHighLBL.isHidden = true
            sumWithSkipLBL.isHidden = true
            seqLBL.isHidden = true
            
            // Do any additional setup after loading the view, typically from a nib.
        }

        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }


    }

