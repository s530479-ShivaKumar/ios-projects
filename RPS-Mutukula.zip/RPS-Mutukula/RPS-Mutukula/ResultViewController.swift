//
//  ResultViewController.swift
//  RPS-Mutukula
//
//  Created by student on 2/18/18.
//  Copyright © 2018 student. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {
    @IBOutlet weak var RestrictCount: UIButton!
    @IBOutlet weak var ResultLBL: UILabel!
    @IBOutlet weak var P_1WinCountLBL: UILabel!
    @IBOutlet weak var P_2WinCountLBL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ResultLBL.isHidden = true

        // Do any additional setup after loading the view.
    }
    @IBAction func reset(_ sender: Any) {
        AppDelegate.model._player1Choice = .None
        AppDelegate.model._player2Choice = .None
        ResultLBL.text = "\(AppDelegate.model._P_1Name) and \(AppDelegate.model._P_2Name) : Make your selection on the other tabs"
        ResultLBL.isHidden = false
        RestrictCount.isEnabled = true
//        Player_1ViewController.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        if AppDelegate.model.haveResult() {
            if(RestrictCount.isEnabled == true){
                ResultLBL.text = AppDelegate.model.winner()
            }
            
        }
        else if AppDelegate.model._player1Choice == .None && AppDelegate.model._player2Choice == .None{
            ResultLBL.text = "\(AppDelegate.model._P_1Name) and \(AppDelegate.model._P_2Name) : Make your selection on the other tabs"
        }
        else if AppDelegate.model._player2Choice == .None{
            ResultLBL.text = "\(AppDelegate.model._P_2Name) : Make your selection on the other tabs"
        }
        else {
            ResultLBL.text = "\(AppDelegate.model._player1Choice) : Make your selection on the other tabs"
        }
        ResultLBL.isHidden = false
        if(RestrictCount.isEnabled == true){
            P_1WinCountLBL.text = "\(AppDelegate.model._P_1Name) win count:" + String(AppDelegate.model._player1WinCount)
            P_2WinCountLBL.text = "\(AppDelegate.model._P_2Name) win count:" + String(AppDelegate.model._player2WinCount)
            RestrictCount.isEnabled = false
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
