//
//  Model.swift
//  RPS-Mutukula
//
//  Created by student on 2/18/18.
//  Copyright © 2018 student. All rights reserved.
//

import UIKit

class RPSModel{
    private static var rpsmodelshared:RPSModel{
        let rpsmodel=RPSModel()
        return rpsmodel
    }

    private var player1WinCount : Int = 0
    var _player1WinCount : Int {
        get{
            return player1WinCount
        }
        set{
            player1WinCount = newValue
        }
    }
    private var player2WinCount : Int = 0
    var _player2WinCount : Int {
        get{
            return player2WinCount
        }
        set{
            player2WinCount = newValue
        }
    }
    private var P_1Name : String = "Player 1"
    var _P_1Name : String {
        get{
            return P_1Name
        }
        set{
            P_1Name = newValue
        }
    }
    private var P_2Name : String = "Player 2"
    var _P_2Name : String {
        get{
            return P_2Name
        }
        set{
            P_2Name = newValue
        }
    }
    enum Choice : Int{ case None = 5, Rock = 0, Paper = 2, Scissor = 4, Spock = 1, lizard = 3}
    
    private  var player1Choice : Choice = .None
    var _player1Choice : Choice {
        get{
            return player1Choice
        }
        set {
            player1Choice = newValue
        }
    }
    private var player2Choice : Choice = .None
    var _player2Choice : Choice {
        get {
            return player2Choice
        }
        set{
            player2Choice = newValue
        }
    }
    func choosePlayer1(pick : Choice) {
        player1Choice = pick
        
    }
    func choosePlayer2(pick : Choice) {
        player2Choice = pick
    }
    func haveResult() -> Bool {
        if player1Choice != .None && player2Choice != .None {
            return true
        }
        else{
            return false
        }
    }
    func winner() -> String {
        if ((player2Choice.rawValue + 1) % 5) == player1Choice.rawValue {
            player1WinCount += 1
            return "\(P_1Name) wins!!"
        }
        else if ((player2Choice.rawValue + 2) % 5) == player1Choice.rawValue {
            player1WinCount += 1
            return "\(P_1Name) wins!!"
        }
        else if player2Choice.rawValue == player1Choice.rawValue {
            return "Its a Tie!!"
        }
        else {
            player2WinCount += 1
            return "\(P_2Name) wins!!"
        }
    }
    func reset(){
        player1Choice = .None
        player2Choice = .None
    }
    class func singlemodel() -> RPSModel {
        return rpsmodelshared
    }
    
}
