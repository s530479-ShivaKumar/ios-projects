//
//  FirstViewController.swift
//  RPS-Mutukula
//
//  Created by student on 2/18/18.
//  Copyright © 2018 student. All rights reserved.
//

import UIKit


class Player_1ViewController: UIViewController {
    @IBOutlet weak var P_1RockOutlet: UIButton!
    @IBOutlet weak var P_PaperOutlet: UIButton!
    @IBOutlet weak var P_1ScissorOutlet: UIButton!
    @IBOutlet weak var P_1SpockOutlet: UIButton!
    @IBOutlet weak var P_1LizardOutlet: UIButton!
    @IBAction func NameTXT(_ sender: UITextField) {
//        AppDelegate.model._P_1Name = sender.text!
//        tabBarItem.title = AppDelegate.model._P_1Name
        AppDelegate.model._P_1Name = sender.text!
        tabBarItem.title = AppDelegate.model._P_1Name
    }
    
    
    @IBAction func P_1Rock(_ sender: Any) {
//        self.performSegue(withIdentifier: "GoToSecondPlayer", sender: self)
        AppDelegate.model.choosePlayer1(pick: .Rock)
        P_1SelectedLBL.text = "\(String(describing: AppDelegate.model._P_1Name)) made selection"
        P_1SelectedLBL.isHidden = false

    }
    @IBAction func P_1Paper(_ sender: Any) {
        AppDelegate.model.choosePlayer1(pick: .Paper)
        P_1SelectedLBL.text = "\(String(describing: AppDelegate.model._P_1Name)) made selection"
        P_1SelectedLBL.isHidden = false
    }
    @IBAction func P_1Scissors(_ sender: Any) {
        AppDelegate.model.choosePlayer1(pick: .Scissor)
        P_1SelectedLBL.text = "\(String(describing: AppDelegate.model._P_1Name)) made selection"
        P_1SelectedLBL.isHidden = false
    }
    @IBAction func P_1Spock(_ sender: Any) {
        AppDelegate.model.choosePlayer1(pick: .Spock)
        P_1SelectedLBL.text = "\(String(describing: AppDelegate.model._P_1Name)) made selection"
        P_1SelectedLBL.isHidden = false
    }
    @IBAction func P_1Lizard(_ sender: Any) {
        AppDelegate.model.choosePlayer1(pick: .lizard)
        P_1SelectedLBL.text = "\(String(describing: AppDelegate.model._P_1Name)) made selection"
        P_1SelectedLBL.isHidden = false
    }
    @IBOutlet weak var P_1SelectedLBL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        P_1SelectedLBL.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        if AppDelegate.model._player1Choice == .None {
            P_1SelectedLBL.isHidden = true
        }
        if(AppDelegate.model._player1Choice == .None){
            P_1RockOutlet.isEnabled = true
            P_PaperOutlet.isEnabled = true
            P_1SpockOutlet.isEnabled = true
            P_1ScissorOutlet.isEnabled = true
            P_1LizardOutlet.isEnabled = true
        }
        else {
            P_1RockOutlet.isEnabled = false
            P_PaperOutlet.isEnabled = false
            P_1SpockOutlet.isEnabled = false
            P_1ScissorOutlet.isEnabled = false
            P_1LizardOutlet.isEnabled = false
        }
        
    }


}

