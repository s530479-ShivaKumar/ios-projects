//
//  SecondViewController.swift
//  RPS-Mutukula
//
//  Created by student on 2/18/18.
//  Copyright © 2018 student. All rights reserved.
//

import UIKit

class Player_2ViewController: UIViewController {
    @IBOutlet weak var P_2RockOutlet: UIButton!
    @IBOutlet weak var P_2PaperOutlet: UIButton!
    @IBOutlet weak var P_2ScissorOutlet: UIButton!
    @IBOutlet weak var P_2SpockOutlet: UIButton!
    @IBOutlet weak var P_2LizardOutlet: UIButton!
    
    @IBAction func NameTXT(_ sender: UITextField) {
        AppDelegate.model._P_2Name = sender.text!
        tabBarItem.title = AppDelegate.model._P_2Name
    }
    
    @IBAction func P_2Rock(_ sender: Any) {
        AppDelegate.model.choosePlayer2(pick: .Rock)
        P_2SelectedLBL.text = "\(String(AppDelegate.model._P_2Name)) made selection"
        P_2SelectedLBL.isHidden = false
    }
    
    @IBAction func P_2Paper(_ sender: Any) {
        AppDelegate.model.choosePlayer2(pick: .Paper)
        P_2SelectedLBL.text = "\(String(describing: AppDelegate.model._P_2Name)) made selection"
        P_2SelectedLBL.isHidden = false
    }
    @IBAction func P_2Scissors(_ sender: Any) {
        AppDelegate.model.choosePlayer2(pick: .Scissor)
        P_2SelectedLBL.text = "\(String(describing: AppDelegate.model._P_2Name)) made selection"
        P_2SelectedLBL.isHidden = false
    }
    @IBAction func P_2Spock(_ sender: Any) {
        AppDelegate.model.choosePlayer2(pick: .Spock)
        P_2SelectedLBL.text = "\(String(describing: AppDelegate.model._P_2Name)) made selection"
        P_2SelectedLBL.isHidden = false
    }
    @IBAction func P_2Lizard(_ sender: Any) {
        AppDelegate.model.choosePlayer2(pick: .lizard)
        P_2SelectedLBL.text = "\(String(describing: AppDelegate.model._P_2Name)) made selection"
        P_2SelectedLBL.isHidden = false
    }
    @IBOutlet weak var P_2SelectedLBL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        P_2SelectedLBL.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        if AppDelegate.model._player2Choice == .None {
            P_2SelectedLBL.isHidden = true
        }
        if(AppDelegate.model._player2Choice == .None){
            P_2RockOutlet.isEnabled = true
            P_2PaperOutlet.isEnabled = true
            P_2SpockOutlet.isEnabled = true
            P_2ScissorOutlet.isEnabled = true
            P_2LizardOutlet.isEnabled = true
        }
        else {
            P_2RockOutlet.isEnabled = false
            P_2PaperOutlet.isEnabled = false
            P_2SpockOutlet.isEnabled = false
            P_2ScissorOutlet.isEnabled = false
            P_2LizardOutlet.isEnabled = false
        }
    }


}

