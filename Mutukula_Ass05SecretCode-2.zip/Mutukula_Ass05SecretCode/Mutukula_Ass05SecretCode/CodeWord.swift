//
//  CodeWord.swift
//  Mutukula_Ass05SecretCode
//
//  Created by Mutukula,Shiva Kumar on 2/26/18.
//  Copyright © 2018 Mutukula,Shiva Kumar. All rights reserved.
//

import Foundation

class CodeWord{
    //a
    var symbols : [String] = []
    //b
    var count : Int
    //c
    var code : [String] = []
    //d
    var guess : [String] = []
    //e
    var onSymbol : Int = 0
    //f
    var attempts : Int = 1
    //g
    var status : String = ""
    //h
    init(size : Int) {
        for _ in 1...size{
            symbols.append(String(arc4random_uniform(10)))
        }
        count = symbols.count
        for _ in 1...size{
            let index = Int(arc4random_uniform(UInt32(count)))
            code.append(symbols[index])
        }
    }
    var numericalDiff : Int = 0
    func difference()->Int{
        var diff = 0
        for i in 0..<guess.count{
            
            diff += abs(Int(guess[i])! - Int(code[i])!)
        }
        return diff
    }
    var guessedCode = ""
    //i
    func addSymbolToGuess(sym : String) {
        if(guess.count >= code.count){
            status = "Guess completed: \(matchesCorrect()) correctaa"
            guess.append("x")
            
        }
        else{
            guess.append(sym)
            onSymbol += 1
            status = "Attempt \(attempts): \(onSymbol) symbols guessed."
            guessedCode = ""
            if(onSymbol == code.count){
                for i in 0..<code.count{
                    guessedCode += guess[i]
                    }
                
                status = "Guess completed: \(matchesCorrect()) correct."
                numericalDiff = difference()
                matchedString = matched()
                
                
        }
        
        }
        
    }
    //j
    func matchesCorrect() -> Int {
        var correctPlaces = 0
        for i in 0..<code.count{
            if(code[i] == guess[i]){
                correctPlaces += 1
            }
        }
        return correctPlaces
    }
    //k
    func statusMessage() -> String {
        return status
    }
    //l
    func currentGuess() -> [String] {
        return guess
    }
    //m
    func guessAndCodeMatches() -> Bool {
        return guess == code
    }
    //n
    func playAgain() {
        matchedString = ""
        hintCount = -1
        if(guessAndCodeMatches()){
            count += 1
            code = []
            for _ in 1...count{
                let index = Int(arc4random_uniform(UInt32(count)))
                code.append(symbols[index])
            }
        }
        else{
            
        }
        onSymbol = 0
        guess = []
        attempts += 1
        
    }
    func gameReset(){
        matchedString = ""
        hintCount = -1
        code = []
        onSymbol = 0
        guess = []
        attempts = 1
        status = ""
//        for _ in 1...count{
//            symbols.append(String(arc4random_uniform(10)))
//        }
        count = symbols.count
        for _ in 1...count{
            let index = Int(arc4random_uniform(UInt32(count)))
            code.append(symbols[index])
        }
        
    }
    var hintCount = -1
    func hint() -> Int {
        if(hintCount < code.count-1){
            hintCount += 1
        }
        return hintCount
    }
    func undo(){
//        guess.removeLast()
//        addSymbolToGuess(sym: "")
//        onSymbol -= 1
    }
    var matchedString = ""
    func matched() -> String {
        var str = ""
        for i in 0..<count
        {
            if code[i] == guess[i]{
                str += guess[i]
            }
            else{
                str += "-"
            }
        }
        return str
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
