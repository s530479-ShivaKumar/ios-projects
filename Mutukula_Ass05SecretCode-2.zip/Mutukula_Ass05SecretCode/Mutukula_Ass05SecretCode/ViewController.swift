//
//  ViewController.swift
//  Mutukula_Ass05SecretCode
//
//  Created by Mutukula,Shiva Kumar on 2/26/18.
//  Copyright © 2018 Mutukula,Shiva Kumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return AppDelegate.myModel.symbols.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = AppDelegate.myModel.symbols[indexPath.row]
        
        return cell!
        
    }
//    func tableView(tableView : UITableViewCell,didSelectRowAt indexPath : IndexPath){
//        //let selectedCell = tableView.cellForRowAtIndexPath(indexPath)
//        //let selectedCell = tableView.
//        AppDelegate.myModel.guess.append(AppDelegate.myModel.symbols[indexPath.row])
//        guessLBL.text = AppDelegate.myModel.guess[indexPath.row]
//
//    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        AppDelegate.myModel.addSymbolToGuess(sym: AppDelegate.myModel.symbols[indexPath.row])
        statusLBL.isHidden = false
        if(AppDelegate.myModel.guess.count <= AppDelegate.myModel.code.count){
            let sizeOfGuess = AppDelegate.myModel.guess.count
            
//            for i in 0..<AppDelegate.myModel.guess.count{
//                guessLBL.text = guessLBL.text! + AppDelegate.myModel.guess[i]
//            }
           guessLBL.text = guessLBL.text! + AppDelegate.myModel.guess[sizeOfGuess-1]
            
            statusLBL.text = AppDelegate.myModel.statusMessage()
//            AppDelegate.myModel.difference()
            numDiffLBL.text = String(AppDelegate.myModel.numericalDiff)
        }
        if(AppDelegate.myModel.guess.count == AppDelegate.myModel.code.count){
             matchedLBL.text = AppDelegate.myModel.matchedString
        }
        
        
    }
    
    @IBOutlet weak var matchedLBL: UILabel!
    @IBOutlet weak var numDiffLBL: UILabel!
    @IBAction func gameReset(_ sender: Any) {
        preGuess.text = ""
        AppDelegate.myModel.gameReset()
        guessLBL.text = "Guess: "
        statusLBL.isHidden = true
        hintLBL.text = ""
        numDiffLBL.text = ""
        preGuess.text = AppDelegate.myModel.guessedCode
        matchedLBL.text = ""
        
    }
    @IBAction func reset(_ sender: Any) {    // function name to be play again.
        AppDelegate.myModel.playAgain()
        preGuess.text = ""
//        AppDelegate.myModel.guess = []
        guessLBL.text = "Guess: "
        statusLBL.isHidden = true
        hintLBL.text = ""
        numDiffLBL.text = ""
        preGuess.text = AppDelegate.myModel.guessedCode
        
        
        
        
    }
    @IBAction func undoBTN(_ sender: Any) {
        AppDelegate.myModel.undo()
        
//        AppDelegate.myModel.code.removeLast()
//        let text = String(describing: guessLBL.text?.dropLast())
//
//        guessLBL.text! = text
    }
    @IBOutlet weak var hintLBL: UILabel!
    
//    @IBAction func HintBTN(_ sender: Any) {
//        let x = AppDelegate.myModel.hint()
//        hintLBL.text! += String(AppDelegate.myModel.code[x])
//    }
    @IBAction func hintBTN(_ sender: Any) {
        if(AppDelegate.myModel.hintCount < AppDelegate.myModel.code.count - 1){
            let x = AppDelegate.myModel.hint()
            hintLBL.text! += String(AppDelegate.myModel.code[x])
        }
        
    }
    @IBOutlet weak var preGuess: UILabel!
    
    @IBOutlet weak var guessLBL: UILabel!
    @IBOutlet weak var statusLBL: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

